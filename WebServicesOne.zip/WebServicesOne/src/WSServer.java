
public class WSServer {
public float convertToCelsius(float farenhite) {
	return (float) ((farenhite - 32)/ (1.8) );
}
}
