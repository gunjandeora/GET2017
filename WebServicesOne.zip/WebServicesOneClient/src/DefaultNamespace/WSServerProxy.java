package DefaultNamespace;

public class WSServerProxy implements DefaultNamespace.WSServer {
  private String _endpoint = null;
  private DefaultNamespace.WSServer wSServer = null;
  
  public WSServerProxy() {
    _initWSServerProxy();
  }
  
  public WSServerProxy(String endpoint) {
    _endpoint = endpoint;
    _initWSServerProxy();
  }
  
  private void _initWSServerProxy() {
    try {
      wSServer = (new DefaultNamespace.WSServerServiceLocator()).getWSServer();
      if (wSServer != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)wSServer)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)wSServer)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (wSServer != null)
      ((javax.xml.rpc.Stub)wSServer)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public DefaultNamespace.WSServer getWSServer() {
    if (wSServer == null)
      _initWSServerProxy();
    return wSServer;
  }
  
  public float convertToCelsius(float farenhite) throws java.rmi.RemoteException{
    if (wSServer == null)
      _initWSServerProxy();
    return wSServer.convertToCelsius(farenhite);
  }
  
  
}